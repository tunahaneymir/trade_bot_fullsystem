# pa-strateji2
Price Action Stratejisi (RL Machine Learning)
